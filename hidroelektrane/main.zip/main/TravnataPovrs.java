package main;

import java.awt.Color;

public class TravnataPovrs  extends Parcela {

	public TravnataPovrs() {
		super('\"', Color.GREEN);
		// TODO Auto-generated constructor stub
	}

}
