package main;

import java.awt.Color;

public class VodenaPovrs extends Parcela{

	public VodenaPovrs() {
		super('~',Color.CYAN);
		
	}

	
}
